Example of event:

{
  "instances": ["test-instance-id"],
  "action": "start"
}


Action can be 'start' or 'stop'.